# Titans Bible — Index

| File | Contents |
|---|---|
| 01_core_theory.md | Memory math: loss, surprise, momentum, forgetting, retrieval, persistent tokens, ablation |
| 02_variants.md | MAC / MAG / MAL / LMM, equations, results, causality note for MAC |
| 03_training_parallelization.md | Chunked updates, closed-form chunk update, chunk size, TNT, paper setup |
| 04_benchmarks_and_claims.md | What the paper claims vs what was independently reproduced |
| 05_followup_research.md | MIRAS, ATLAS, Nested Learning/HOPE, Memory Caching, Proteus, baselines; what to borrow |
| 06_implementations_and_tools.md | lucidrains titans-pytorch, other repos, fla, checkpoints |
| 07_optimizations.md | Cost model, speed, precision, quantization, stability |
| 08_hardware_strix_halo.md | gfx1151 ROCm/PyTorch setup, env vars, known bugs, sizes that fit in 128 GB |
| 09_strategy_retrofit_and_agent.md | From scratch vs frozen-LLM adapter; agent memory design |
| 10_limitations.md | Honest limits |
| 11_roadmap.md | Phases P0–P9 with pass/fail gates |
| VERIFICATION.md | How this pack was checked + errata vs the earlier single-file report |

## Verification tags used in every file
- **[PAPER]** — checked directly against the Titans arXiv PDF (2501.00663) while building this pack.
- **[TESTED]** — code/behaviour executed here; see `tests/`.
- **[SOURCED]** — from the cited research pass (arXiv, GitHub, blogs); not re-checked line by line. Verify before relying on it for a decision.
- **[ESTIMATE]** — reasoning or back-of-envelope; not measured.
- **[UNVERIFIED]** — could not confirm; treat as a lead.

Nothing labelled [SOURCED] about ROCm/gfx1151 should be trusted past a few weeks; that stack changes weekly.
