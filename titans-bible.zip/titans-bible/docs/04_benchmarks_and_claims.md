# 04 — Benchmarks: Claims vs Reproduction

| Claim | Source | Status |
|---|---|---|
| Beats Transformer++ and linear RNNs at 340M–760M | Titans Table 1 | Author-reported [PAPER]; some baselines imported from the Gated DeltaNet paper [SOURCED] |
| S-NIAH ≥95% at 16K (MAC) | Titans Table 2 | Author-reported [SOURCED] |
| BABILong: fine-tuned MAC beats GPT-4, Llama3.1-8B+RAG with ~70× fewer params | Titans Fig. 6 | Author-reported; baselines taken from Kuratov et al. 2024 [SOURCED] |
| Context > 2M tokens | Abstract | Author-reported; no public model to test [PAPER] |
| Time series / DNA wins | Tables 3–4 | Author-reported; DNA baselines reused from prior work [SOURCED] |
| Independent reimplementation | "Titans Revisited", arXiv 2510.09551 | Titans does not always beat baselines because of chunking, but the neural memory component consistently helps over attention-only models [SOURCED] |
| Fact storage vs recall | Knowledge Objects, arXiv 2603.17781 | MAC at dim 128 memorised 100% but only 0–40% free-form recall [SOURCED] |

Reported headline for the Dec 2025 Google blog coverage: the largest Titans evaluated was ~760M params. [SOURCED]

## What this means for you
The mechanism is real; the size of the gains at scale is not independently confirmed. Your own gates
(docs/11) decide, especially: **memory model must beat the identical `--no-memory` baseline on passkey at
lengths beyond the attention window**, and the adapter must beat plain text retrieval (RAG).

## Reproducing the paper's evals locally
- RULER S-NIAH (passkey / number / word) — compare at 4K, 16K, 64K.
- BABILong qa1–qa5.
- Language modelling: Wikitext, LAMBADA; commonsense: PIQA, HellaSwag, WinoGrande, ARC-e/c, SIQA, BoolQ
  (use lm-evaluation-harness once a tokenizer-based model exists).
- `scripts/eval_passkey.py` is a quick byte-level stand-in, meaningful only as a *relative* comparison.
