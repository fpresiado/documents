# 05 — Follow-up Research and What to Borrow

All entries [SOURCED] unless marked.

## MIRAS — "It's All Connected" (arXiv 2504.13173, Google)
Every sequence model = 4 choices: **memory architecture**, **attentional bias** (inner objective),
**retention gate** (forgetting, recast as regularisation), **memory learning algorithm** (optimiser).
Most existing models use dot-product similarity or L2 regression as the inner objective.
| Variant | Memory | Attentional bias | Retention |
|---|---|---|---|
| Moneta | 2-layer MLP | ℓp | ℓq + ℓ2 |
| Yaad | MLP | Huber | local + global |
| Memora | MLP | ℓ2 | KL (simplex memory) |
**Borrow:** Yaad's Huber inner loss makes writes robust to outlier tokens. Implemented as
`NeuralMemory(..., huber_delta=1.0)`. [TESTED runs]

## ATLAS (arXiv 2505.23735, Google)
- **Omega rule:** optimise memory over a sliding window of the last c tokens, not just the current token.
- Polynomial feature maps on q/k; **Muon** as the inner optimiser; DeepTransformers / OmegaNet.
- Claims large BABILong gains at 10M context; an independent review notes main-table baselines were imported.
**Borrow:** Omega window c = 4–16 (sum the loss over the last c (k, v) pairs). Not implemented yet.

## Google Research blog "Titans + MIRAS: Helping AI have long-term memory" (Dec 2025)
Official overview. No code released.

## Nested Learning / HOPE (arXiv 2512.24695, Google)
Continuum Memory System: MLP blocks updated at different frequencies; HOPE is a self-modifying Titans variant.
**Borrow:** multi-frequency memory — fast memory per chunk, session memory per turn, slow memory nightly.

## Memory Caching (arXiv 2602.24281, ICML 2026)
Caches memory-state checkpoints per segment so capacity grows with length (between O(L) and O(L²)).
**Borrow:** save memory snapshots per session/topic (`state_io.save_states`) and retrieve over snapshots.

## Proteus (arXiv 2608.16844, Aug 2026)
Incremental memory activation — unlocks memory blocks as context grows; parameter-free; improves Titans and
several linear-attention models.

## In-Place TTT (arXiv 2604.06169)
Uses the Transformer's own MLPs as fast weights. Relevant to retrofitting pretrained models.

## Baselines you must beat
**Gated DeltaNet** (arXiv 2412.06464; in fla; used in Qwen3-Next) is the strongest cheap alternative. Also
Mamba-2 and TTT. Rule: your Titans layer must beat fla Gated DeltaNet on your NIAH gate before you scale up.
