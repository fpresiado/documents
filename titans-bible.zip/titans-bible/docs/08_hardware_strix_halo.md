# 08 — Hardware: Framework Desktop (Ryzen AI MAX+ 395, gfx1151, 128 GB) + Threadripper 2970WX

Everything in this file is [SOURCED] from community issues/guides (Jan–Sep 2026) and was **not** run on your
machine. Re-verify with the P0 gate.

## PyTorch on gfx1151
- gfx1151 was not on AMD's official ROCm support matrix as of early 2026; it works via TheRock nightlies.
- Install: `pip install --pre torch --index-url https://rocm.nightlies.amd.com/v2/gfx1151/`
  ("Stable ROCm does not ship gfx1151 kernels" — ROCm issue #6034).
- Container alternatives: `kyuz0/amd-strix-halo-pytorch-gfx1151-aotriton`, `rocm/pytorch-nightly`.
- Pin the nightly that passes P0; don't float.

## Environment (`env/strix_halo.sh`)
```bash
export TORCH_ROCM_AOTRITON_ENABLE_EXPERIMENTAL=1   # before importing torch; reported 4096-tok attn 135 ms -> 12 ms
unset HSA_OVERRIDE_GFX_VERSION                     # breaks native gfx1151 kernels with native wheels
unset PYTORCH_HIP_ALLOC_CONF                       # #6034 advises unsetting
# FLASH_ATTENTION_TRITON_AMD_ENABLE=TRUE           # only if using the ROCm flash-attention fork
```
Conflicting advice exists: older guides still recommend `HSA_OVERRIDE_GFX_VERSION=11.0.0/11.5.1`. That was for
non-native builds. With native gfx1151 wheels, leave it unset.

## Known problems
- bf16 bugs and NaNs at some batch sizes (#6034) → memory math already fp32; run with and without `--bf16`.
- Silent GPU hangs / PERMISSION_FAULT reported (#6530, #6186, #6165) → checkpoint ≤ every 30 min, add a
  step-time watchdog.
- fla kernels: num_warps > 4 trips Triton LinearLayoutConversions assertions → patch to ≤ 4.
- Early TheRock builds lacked flash SDPA on gfx1151 (TheRock #1364).

## P0 check script
```python
import os; os.environ.setdefault("TORCH_ROCM_AOTRITON_ENABLE_EXPERIMENTAL", "1")
import time, torch, torch.nn.functional as F
print(torch.__version__, torch.version.hip, torch.cuda.is_available(), torch.cuda.get_device_name(0))
a = torch.randn(2048, 2048, device="cuda", dtype=torch.bfloat16); print("bf16 mm ok", torch.isfinite(a @ a).all().item())
q = torch.randn(1, 8, 4096, 64, device="cuda", dtype=torch.bfloat16)
F.scaled_dot_product_attention(q, q, q, is_causal=True); torch.cuda.synchronize()
t = time.time(); F.scaled_dot_product_attention(q, q, q, is_causal=True); torch.cuda.synchronize()
print(f"sdpa 4096: {(time.time()-t)*1e3:.1f} ms  (gate: < 50 ms)")
```
Then `python -m pytest -q` on the GPU box.

## Memory and bandwidth
- 256-bit LPDDR5x-8000: 256 GB/s theoretical, ~215 GB/s measured in one guide.
- Windows: AMD recommends 96 GB VGM for best performance; iGPU can address up to ~112 GB on 128 GB systems.
- Bandwidth-bound → MoE models run much faster than dense 70B.

## What fits [ESTIMATE]
| Workload | Feasible? |
|---|---|
| From-scratch MAG/MAC 30–170M | Yes — main target, days–weeks |
| From-scratch 340–400M | Marginal, weeks |
| 760M / 30B-token reproduction | No, compute-bound |
| Frozen 4–8B bf16 + adapter | Yes |
| Frozen 14–32B 4–8 bit + adapter | Yes, slower |
| 70–120B MoE GGUF inference (llama.cpp) | Yes, but Titans adapter needs a PyTorch backbone |

## Big-model inference
llama.cpp with Vulkan (RADV) is easiest; ROCm/HIP with flash attention holds up better at long context.

## Threadripper 2970WX (24 Zen+ cores, no AVX-512)
Data download/tokenising/dedup, building RULER/BABILong sets, CPU test runs and CI, llama.cpp CPU fallback.
Not for training.
