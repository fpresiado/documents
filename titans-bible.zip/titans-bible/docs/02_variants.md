# 02 — Variants: MAC, MAG, MAL, LMM

## MAC — Memory as Context (best long-context recall) [PAPER]
Split the sequence into segments S^(t). For each segment:
```
h_t  = M*_{t-1}(q_t),  q_t = S^(t) W_Q           (21)  retrieve history
S~   = [p_1 … p_Np] || h_t || S^(t)              (22)
y_t  = Attn(S~)                                   (23)  attention decides what history is useful
M_t  = M_{t-1}(y_t)                               (24)  write attention output into memory
o_t  = y_t ⊗ M*_t(y_t)                            (25)
```
**Causality gap (important).** q_t is computed from the whole segment, so h_t[i] carries token i's content.
The paper does not specify the attention mask for [P | h | S]. With a plain lower-triangular mask over the
concatenation (what the earlier single-file report did), segment token j can see h_t[i] for i > j, so it
**leaks future tokens**. That was demonstrated here: the old mask fails the causality test, the fixed mask
passes. [TESTED] Fix in `titan/model.py::mac_mask`: token j sees P, h_t[0..j], S[0..j].
lucidrains avoids the issue differently, using a small number of learned long-term memory tokens
(`num_longterm_mem_tokens`) instead of per-position history. [SOURCED]

## MAG — Memory as Gate (build this first) [PAPER]
```
x~ = [P] || x;   y = SW-Attn*(x~);   o = y ⊗ M(x~)            (26–28)
```
No segmentation. Sliding-window attention = precise short-term memory; neural memory = fading long-term
memory. Both branches normalised and combined through a nonlinear gate. Simplest to get right. [TESTED causal]

## MAL — Memory as Layer [PAPER]
```
x~ = [P] || x;   y = M(x~);   o = SW-Attn(y)                  (29–31)
```
Plain hybrid stacking. Fastest (can use FlashAttention directly) but weakest: each layer bottlenecks the other.

## LMM — neural memory alone, no attention.

## Results at 760M / 30B tokens (Table 1) [PAPER]
| Model | Wiki ppl ↓ | LMB ppl ↓ | Avg acc ↑ |
|---|---|---|---|
| Titans (LMM) | 20.04 | 21.96 | 51.56 |
| Titans (MAC) | 19.93 | 20.12 | 52.51 |
| Titans (MAG) | 18.61 | 19.86 | 52.50 |
| Titans (MAL) | 19.07 | 20.33 | 50.97 |
Baselines from the same table [SOURCED]: Transformer++ 25.21/27.64/48.69; Mamba2 22.94/28.37/48.34;
Gated DeltaNet 21.18/22.09/49.69; Gated DeltaNet-H2 19.88/20.83/51.49.

## S-NIAH (RULER) at 16K — passkey / number / word [SOURCED, author-reported]
| Model | PK | N | W |
|---|---|---|---|
| MAC | 98.4 | 97.4 | 95.2 |
| MAG | 97.4 | 98.6 | 88.2 |
| MAL | 97.8 | 96.4 | 90.4 |
| LMM | 96.2 | 80.2 | 80.6 |
| TTT | 88.4 | 4.4 | 0.0 |
| Mamba2 | 5.4 | 0.0 | 0.0 |
| DeltaNet | 71.4 | 5.4 | 0.0 |

## Decision
MAG ≈ MAC on language modelling; MAC better on long recall; MAL fastest. Build **MAG → MAC**.
