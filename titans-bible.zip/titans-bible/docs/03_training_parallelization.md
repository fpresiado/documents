# 03 — Training & Parallelization

## Chunked mini-batch updates (Eq. 16) [PAPER]
Split the sequence into chunks of size b. Every gradient inside a chunk is taken at the weights from the
start of the chunk (t' = t − mod(t, b)):
```
M_t = β_t M_0 − Σ_{i≤t} θ_i (β_t/β_i) ∇l(M_{t'}; x_i),   β_i = Π_{j≤i} (1 − α_j)
```
So a chunk's gradients are independent and computed in one batched call (`vmap(grad(loss))`). The
recurrence is **non-linear across chunks, linear within a chunk** — the key difference from Gated DeltaNet.
Builds on TTT's dual-form trick (Sun et al., arXiv 2407.04620). [SOURCED]

## Closed-form chunk update (this pack) [TESTED]
Applying Eqs. 13–14 token by token inside a chunk is correct, but under autograd it keeps one full copy of
the memory weights per token, so memory grows with sequence length (a tiny-preset run exited silently; likely this, not confirmed).
`titan/memory.py::chunk_update` computes the identical end-of-chunk W and S from b×b scalar coefficients:
```
E[i,t] = Π_{j=i+1..t} η_j          A[t] = Π_{j=t+1..b} (1 − α_j)
S_b = E[0,b] S_0 − Σ_i E[i,b] θ_i G_i
W_b = A[0] W_0 + (Σ_t A[t] E[0,t]) S_0 − Σ_i θ_i (Σ_{t≥i} A[t] E[i,t]) G_i
```
It matches the loop to 1e-9 in float64 (`test_closed_form_chunk_update_matches_loop`). Products are taken in
log space; gates are clamped at 1e-30 before the log.

## Momentum as an associative scan [PAPER]
S_t = η_t S_{t−1} − θ_t u_t is a linear recurrence, so across long chunks it can also be computed with a
parallel associative scan (lucidrains uses `assoc-scan`). With per-chunk constant gates it becomes a global
convolution. The closed form above is the same idea specialised to one chunk.

## Chunk size tradeoff
- Small b (4–16): finer updates, better quality, lower hardware utilisation.
- Large b (64–512): faster, but updates are blurred.
- MIRAS reports b "usually is 16 or 64". lucidrains `train_mac.py` uses segment 4, batch 128. [SOURCED]
- Default here: 16, then sweep {8, 16, 32, 64} (roadmap P9).

## Inner learning rate stability [TESTED]
With `max_lr≈1` and b=8, the b gradients (all taken at the same weights) add up and overshoot; memory weights
reached ~1e27 within 5 passes. With `max_lr=0.1` the associative loss falls steadily. Keep `max_lr ≤ 0.1`
initially; lucidrains' default `default_step_transform_max_lr` is 1e-1 [SOURCED]. Optional extra guard:
clip the surprise by spectral norm (lucidrains `spectral_norm_surprises`).

## TNT (Google, arXiv 2511.07343, ICLR 2026) [SOURCED]
Two stages: (1) hierarchical memory — a global memory on large chunks plus parallel local memories that are
periodically reset, breaking the sequential dependency; (2) a short fine-tune. Reports up to 17× faster
training than the most accurate baseline configuration, with better accuracy, on Titans and TTT. Use it if
chunk-sequential throughput becomes your bottleneck.

## Relatives [SOURCED]
- Gated DeltaNet = LMM with linear memory and η = 0.
- TTT = no forgetting, no momentum.
- RWKV-7 uses the same regression-style loss.

## Paper training setup [PAPER]
- Sizes 170M / 340M / 400M on **15B** FineWeb-Edu tokens; 760M on **30B**.
- Llama 2 tokenizer, 32K vocab; training length 4K tokens.
- AdamW, lr 4e-4, cosine schedule, batch 0.5M tokens, weight decay 0.1.
- A 1.3B / 100B-token model appears in the OpenReview version. [SOURCED]

## Training loop used here (`scripts/train.py`) [TESTED]
Truncated BPTT: the sequence is fed as `bptt` consecutive segments; memory *contents* carry across segments,
the autograd graph is cut (`NeuralMemory.detach_state`). Grad clip 1.0, AdamW (0.9, 0.95), wd 0.1, warmup +
cosine. Smoke run (tiny preset, CPU, 40 steps): val 6.98 → 1.43 bits/byte.
