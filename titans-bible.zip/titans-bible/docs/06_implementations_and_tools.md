# 06 — Implementations and Tools

## Official code: none [PAPER]
The paper states: "Titans are implemented in Pytorch and JAX and we intend to make the code we used to train
and evaluate our models available soon." No official code or weights have appeared.

## This pack's implementation [TESTED]
`titan/` — from scratch, readable, 16 tests. Use it as the primary codebase: you control every gate,
chunk size and state-saving path.

## lucidrains/titans-pytorch (unofficial, MIT) [SOURCED]
- PyPI `titans-pytorch`, import `titans_pytorch`. Latest seen: **v0.5.5 (13 Jul 2026)**; needs torch ≥ 2.8.
- Deps include `assoc-scan`, `einops`, `einx`, `hyper-connections`, `rotary-embedding-torch`, `tensordict`,
  `x-transformers`.
- Exports: `NeuralMemory`, `NeuralMemState`, `mem_state_detach`, `MemoryMLP`, `MemoryAttention`,
  `FactorizedMemoryMLP`, `MemorySwiGluMLP`, `GatedResidualMemoryMLP`, `MemoryAsContextTransformer`.
```python
# pip install titans-pytorch==0.5.5
from titans_pytorch import NeuralMemory, MemoryAsContextTransformer
mem = NeuralMemory(dim=384, chunk_size=64)
retrieved, mem_state = mem(seq)   # README form; passing state back in: check the kwarg in neural_memory.py
model = MemoryAsContextTransformer(num_tokens=256, dim=256, depth=2, segment_len=128,
                                   num_persist_mem_tokens=4, num_longterm_mem_tokens=16)
```
Known issues:
- #18: `torch.func.{grad, vjp,…} don't yet support saved tensor hooks` under activation checkpointing.
- #19: fails inside JIT-scripted modules.
- #64: per-head memory parameters alias one tensor; optimiser steps / `load_state_dict` fail for heads > 1 → **use heads=1**.
- #51: no pretrained weights.
[UNVERIFIED] the exact kwarg name for feeding `mem_state` back in; read `neural_memory.py` at your pinned version.
Use it as a cross-check (train both on the same data), not as your base.

## Other repos [SOURCED]
- **javilima01/Titans** — memory adapter on a frozen Qwen; fp32 memory, bf16 backbone, per-user state files bound to adapter weights; synthetic + BABILong/QASPER training with a text-retrieval control. Closest template for Track B.
- **Aedelon/titans-pytorch-mlx** — MAC/MAG/MAL in PyTorch and MLX.
- **danielquintas8/atlas-torch** — ATLAS.
- **ddidacus/llama-titans** — Llama-3.2-1B with Titans memory.
- **kolejnyy/titans-lmm** — small readable MAC proof of concept.
- **TPTT** (arXiv 2506.17671) — converts pretrained Transformers into Titans-style models (Llama, Qwen, Gemma, Mistral).
- **langchain-nmret** — LangChain retriever combining titans-pytorch memory with a vector store.

## flash-linear-attention (fla-org) [SOURCED]
Triton kernels for DeltaNet, **Gated DeltaNet**, RWKV7, Mamba2, and more; "verified on NVIDIA, AMD, and Intel".
**No Titans/ATLAS layer.** Use it for the Gated DeltaNet baseline. On gfx1151 kernels with num_warps > 4 hit a
Triton assertion — patch to ≤ 4 (see docs/08).

## Checkpoints [SOURCED]
No official weights. Community toys only (e.g. `thebnbrkr/titans-marv-enwik8`, 0.37M params). Train your own.
