# 11 — Roadmap (task list for Claude Code)

| Phase | Task | Gate (must pass) |
|---|---|---|
| P0 | Env: TheRock torch, env vars (docs/08) | P0 script: device visible, bf16 matmul finite, SDPA @4096 < 50 ms; `pytest -q` all pass on GPU |
| P1 | NeuralMemory | `tests/test_memory.py` pass (causality, recall, closed-form == loop, lr-divergence documented) |
| P2 | Toy recall: 64 random k→v pairs | depth-2 memory recall cosine > 0.9 and beats a linear (matrix) memory baseline (add it as a MemoryMLP variant) |
| P3 | MAG small on enwik8 (`--preset small --bf16`) | val < 1.6 bits/byte by 20k steps; no NaN; tok/s and MFU logged |
| P4 | Passkey: memory vs `--no-memory`, same config/steps | memory ≥ 90% @ 4K, ≥ 70% @ 16K; baseline ≤ 20% @ 16K (window 128) |
| P5 | MAC (`--arch mac`) | bpb within 3% of MAG; better passkey at the longest length |
| P6 | Persistence | fact from session 1 recalled after process restart via `state_io`; hash mismatch raises (tested) |
| P7 | Frozen-LLM adapter | init perplexity change < 1%; trained adapter beats RAG control on held-out episodes; MMLU subset drop < 1 pt |
| P8 | Offline agent | network disabled; ≥ 80% recall of 20 facts told across 5 sessions |
| P9 | Optimisation (docs/07) | ≥ 2× tok/s vs P3 with ≤ 2% bpb regression |

Rules: one phase at a time; record every gate result in `runs/<name>/metrics.jsonl`; if a gate fails, stop and
report rather than lowering the gate.

## Data
- enwik8: first 90M bytes train / rest val (standard split). `scripts/train.py` uses a 90/10 split of whatever file you pass.
- BABILong, RULER: generate/fetch once on the Threadripper, store under `data/`.
