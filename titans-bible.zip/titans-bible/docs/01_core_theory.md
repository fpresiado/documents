# 01 — Core Theory (Titans, arXiv 2501.00663)

Behrouz, Zhong, Mirrokni (Google Research). arXiv Dec 2024 / Jan 2025. [PAPER]

## Three memories
- **Short-term memory = attention.** Exact but quadratic and window-limited.
- **Long-term memory = a deep neural network (MLP) trained online at test time.** Compresses history into weights, fixed size regardless of context length.
- **Persistent memory = learnable, input-independent tokens** prepended to the sequence.

## Associative memory objective [PAPER]
```
k_t = x_t W_K        v_t = x_t W_V                               (Eq. 11)
l(M_{t-1}; x_t) = || M_{t-1}(k_t) - v_t ||_2^2                   (Eq. 12)
```
W_K, W_V, W_Q are ordinary parameters (outer loop, trained normally). The memory MLP's weights are the
inner loop: updated by gradient descent on this loss during the forward pass, in training and inference.

## Surprise, momentum, forgetting [PAPER]
```
S_t = eta_t * S_{t-1} - theta_t * grad l(M_{t-1}; x_t)           (Eq. 14)
M_t = (1 - alpha_t) * M_{t-1} + S_t                              (Eq. 13)
```
- grad l = **momentary surprise** (how wrong memory was on this token).
- eta_t * S_{t-1} = **past surprise** (momentum). Without it, gradients can vanish right after a surprising burst and the follow-up tokens are missed.
- alpha_t in [0,1] = **forgetting gate** (adaptive weight decay). alpha→1 wipes memory; alpha→0 keeps it.
- theta_t = inner learning rate. eta, theta, alpha are all data-dependent (functions of x_t).
- Without the forgetting term (Eqs. 9–10) the update is plain momentum SGD.

The paper notes this equals mini-batch GD with momentum and weight decay on a meta-learned network, and that
the alpha gate generalises the forget gates of Mamba-2 / Gated DeltaNet. [PAPER]

## Retrieval [PAPER]
`y_t = M*(q_t)`, `q_t = x_t W_Q` — a forward pass with no weight update (Eq. 15).

## Architectural details (paper §4.4) [PAPER]
SiLU on q/k/v; l2-normalised q and k; 1-D depthwise-separable conv after each q/k/v projection; residual
connections; normalisation + linear gate before the output projection. All present in `titan/memory.py`. [TESTED]

## Why deep memory (L_M ≥ 2)
A matrix memory makes the objective online linear regression: only linear key→value maps are storable. An MLP
with ≥2 layers is strictly more expressive. Ablation: linear memory 28.49 ppl / 85.34 long-context vs deep
memory 27.01 / 92.68. Deeper memory lowers perplexity but throughput drops roughly linearly with depth.
**Default L_M = 2.** [PAPER]

## Persistent memory [PAPER]
`x_new = [p_1 … p_{N_p}] || x` (Eq. 19). Stores task knowledge, acts like data-independent attention, and
soaks up the attention bias toward the first tokens.

## Ablation — Table 5, 760M params [PAPER]
| Variant | LM ppl ↓ | Reasoning acc ↑ | Long-context acc ↑ |
|---|---|---|---|
| LMM | 27.01 | 47.83 | 92.68 |
| +Attn (MAC) | 26.67 | 48.65 | 97.95 |
| +Attn (MAG) | 25.70 | 48.60 | 96.70 |
| +Attn (MAL) | 25.91 | 47.87 | 96.91 |
| Linear memory | 28.49 | 46.97 | 85.34 |
| w/o convolution | 28.73 | 45.82 | 90.28 |
| w/o momentum | 28.98 | 45.49 | 87.12 |
| w/o weight decay | 29.04 | 45.11 | 85.60 |
| w/o persistent memory | 27.63 | 46.35 | 92.49 |

Takeaway: forgetting and momentum matter most for long context; then deep memory; then conv; persistent
tokens least. If you must cut, cut memory depth >2 first, never forgetting or momentum.

## Expressiveness
The paper argues Titans can solve problems beyond TC⁰ (Theorem 4.1), unlike Transformers. [SOURCED]
