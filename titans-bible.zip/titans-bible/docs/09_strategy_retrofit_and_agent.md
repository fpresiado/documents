# 09 — Strategy: From Scratch vs Retrofit, and Agent Memory

## Track A — from scratch (validation)
Byte-level 30–170M MAG then MAC on enwik8 / TinyStories. Cheap; proves causality, persistence and that
memory beats the identical `--no-memory` baseline beyond the attention window. [code TESTED]

## Track B — adapter on a frozen LLM (product)
`titan/adapter.py` [TESTED on a stand-in decoder]:
- Frozen Qwen/Llama/Gemma 1–8B in bf16; memory adapters (residual branch) at 1–3 mid-depth layers.
- Gate initialised at sigmoid(−4) ≈ 0.018 → output change at init is tiny (test asserts < 0.05 logit shift).
- Only adapter params train. Data: synthetic "fact early, question later" episodes + BABILong/QASPER.
- **Always** compare against a text-retrieval (RAG) control. If the adapter doesn't beat RAG on your facts, ship RAG.
```python
from transformers import AutoModelForCausalLM
from titan.adapter import attach
llm = AutoModelForCausalLM.from_pretrained("Qwen/Qwen2.5-1.5B", torch_dtype="bfloat16").cuda()
ads, handles = attach(llm, layers=(14,), mem_dim=512, chunk=32)
opt = torch.optim.AdamW(ads.parameters(), lr=1e-4)
# per episode: for a in ads.values(): a.reset()   -> feed context -> ask question -> loss on answer only
```
[UNVERIFIED] Layer index choice and the adapter's effect on a real Qwen — measure in P7.

Risks [SOURCED]: hidden-state collapse (Prometheus Mind reports 0.98+ similarity between different entities);
training collapse needing stage-wise training; storing facts without recalling them (Knowledge Objects); MMLU
drops; checkpointing conflicts (titans-pytorch #18).

## Zero-cloud agent memory design [ESTIMATE — design, not tested end-to-end]
1. Frozen local LLM.
2. Neural adapter; one memory state file per user (`state_io`, hash-bound to adapter weights).
3. Snapshot archive per session/topic (Memory Caching idea) — retrieve and load the relevant snapshot.
4. Local vector store as ground truth for exact facts.
5. Update frequencies (Nested Learning idea): per chunk (inference), per turn (session), nightly consolidation
   by replaying the day's transcripts.
6. Use `NeuralMemory.surprise()` (per-token gradient norm) as an importance score: write high-surprise turns to
   the vector store. [TESTED function exists; usefulness unmeasured]
