# 07 — Optimizations

## Cost model [ESTIMATE]
Each memory layer costs roughly 3× the memory-MLP FLOPs per token (read + per-token gradient), in training
**and** inference, on top of the Transformer block. Measured here on 2 CPU cores: one NeuralMemory layer,
dim 128, 8×256 tokens ≈ 0.4–1.6 s forward, ~0.4–1 s backward [TESTED — CPU only, not a GPU number].
- Put memory in only some layers (lucidrains example: layers 2, 4, 6).
- Throughput falls about linearly with memory depth [PAPER].

## Speed, in order of payoff
1. **Closed-form chunk update** (done, `chunk_update`) — removes per-token weight copies. [TESTED]
2. **Chunk size sweep** {8, 16, 32, 64}: log tok/s, val bpb, passkey; pick the knee.
3. **torch.compile** the attention + MLP blocks; pad T to a multiple of the chunk size to avoid recompiles.
   functorch transforms may cause graph breaks — compile around NeuralMemory first. [ESTIMATE]
4. **Attention** through `F.scaled_dot_product_attention` (AOTriton on ROCm; docs/08).
5. **Fused kernel** for the chunk step (vmap-grad → coefficients → weighted sum) in Triton — only after 1–4.
6. **TNT** hierarchical memory if large chunks are required for speed (docs/03).

## Precision
- Backbone bf16 (`--bf16`); memory W, S, gates, inner loss fp32 — enforced in `NeuralMemory`. [TESTED fp32 path]
- Cap `max_lr` (0.1). Optional spectral-norm clipping of surprise.

## Quantization
Quantize only the frozen backbone (GGUF / AWQ / bitsandbytes 4–8 bit). Never quantize memory W or S.

## Memory state vs KV cache [ESTIMATE]
State size = layers × memory params × 2 (W and S) × 4 bytes. Example: 8 layers, dh 512, expansion 2 →
~1M params/layer → ~64 MB total, constant regardless of context length. MAG additionally needs only a
window-sized KV cache. A full KV cache for 1M tokens is many GB.

## Training budget [ESTIMATE, not measured]
170M params × 3.4B tokens ≈ 6·N·D ≈ 3.5e18 FLOPs ≈ 4 days at an assumed 10 TFLOPS sustained, plus 1.5–3× for
memory layers. Measure MFU in P3 and re-plan.
