# 10 — Honest Limitations

1. **No official code or weights.** [PAPER] Every implementation, including this one, is a reconstruction.
2. **MAC masking is under-specified** in the paper; a naive mask leaks the future. [TESTED] See docs/02.
3. **Reproducibility.** "Titans Revisited" (arXiv 2510.09551) cites missing code and ambiguous descriptions;
   gains shrink with chunking. Baselines in Titans/ATLAS partly imported, not rerun. [SOURCED]
4. **Speed.** Test-time gradients cost real compute in inference too; the paper itself says the memory is
   slightly slower than Mamba2 / Gated DeltaNet. [SOURCED]
5. **Instability.** High inner lr diverges [TESTED]; bf16 + gfx1151 bugs compound it [SOURCED].
6. **Storage ≠ recall.** Parametric memory can hold a fact and fail to retrieve it. [SOURCED]
7. **Scale.** Nothing reported above ~1.3B. [SOURCED]
8. **Hardware.** gfx1151 unofficial; hangs reported. [SOURCED]
9. **This pack** was tested on CPU only (torch 2.14.0+cpu). GPU/ROCm behaviour, speed and long runs are
   unverified until your P0–P4 gates pass.
