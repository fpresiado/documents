# VERIFICATION — how this pack was checked, and errata vs the single-file report

## Answer to "was accuracy lost by using one file?"
Splitting into files does not change accuracy by itself. What mattered: the single-file report's **code had
never been executed**, and many claims were only as good as the research pass. For this pack:

## What was checked
1. **Paper facts re-checked against the arXiv PDF** (2501.00663): Eqs. 9–14 and 19, MAC Eqs. 21–25, Table 5
   ablation (all 9 rows), Table 1 Titans rows at 760M, training setup (sizes, 15B/30B tokens, Llama-2 32K
   tokenizer, 4K length, AdamW 4e-4 cosine, 0.5M-token batches, wd 0.1), and the code-release sentence.
   All matched the earlier report.
2. **All code executed** on CPU (Python 3.11, torch 2.14.0+cpu): 16 unit tests pass; training smoke run
   (val 6.98 → 1.43 bits/byte in 40 steps); MAC training runs; passkey script runs; state save/load round-trips.

## Errata — bugs in the earlier single-file report's code (fixed here)
| # | Problem | Evidence | Fix |
|---|---|---|---|
| 1 | **MAC leaked future tokens**: plain lower-triangular mask over [P‖h‖S] lets token j see h[i>j], which encodes token i | Causality test: old mask FAIL, new mask PASS | `mac_mask` in `titan/model.py` |
| 2 | **Per-token update loop keeps one weight copy per token in the autograd graph** — memory grows with sequence length | A tiny-preset run exited silently; cause not confirmed (likely memory) | Exact closed-form `chunk_update`, matches the loop to 1e-9 |
| 3 | **No warning on inner-lr divergence**: `max_lr≈1` blew weights up to ~1e27 | `test_too_high_inner_lr_diverges` | Rule: `max_lr ≤ 0.1`; documented |
| 4 | Checkpoint hash used only the first 4 KB of each tensor | Code review | Hash full tensors |
| 5 | `torch.func.grad` under a caller's `no_grad` relied on unverified behaviour | Code review | `NeuralMemory.forward` wraps in `enable_grad`; tested |
| 6 | Scripts hard-coded `.cuda()` | Code review | Device auto-select (cuda/HIP → cpu) |

## Still not verified (by nature)
- Anything about gfx1151/ROCm (docs/08): community sources, not run on your machine.
- lucidrains API details beyond the README (state-passing kwarg).
- Author-reported benchmark numbers beyond the tables above.
- Throughput and training-time estimates.
- Adapter behaviour on a real pretrained LLM (tested only on a stand-in).
"100% accurate" is not achievable for a moving research area; the tags in each file tell you exactly what
level of trust each statement has.
