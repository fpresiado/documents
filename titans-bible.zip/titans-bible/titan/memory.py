"""Titans neural long-term memory (from-scratch reference implementation).

Paper: Behrouz, Zhong, Mirrokni, "Titans: Learning to Memorize at Test Time", arXiv 2501.00663.
Equations implemented (numbers refer to the paper):
  k_t = x_t W_K, v_t = x_t W_V                               (Eq. 11)
  loss  l(M; x_t) = ||M(k_t) - v_t||^2                       (Eq. 12)
  S_t = eta_t * S_{t-1} - theta_t * grad l(M_{t-1}; x_t)     (Eq. 14)  momentum = past surprise
  M_t = (1 - alpha_t) * M_{t-1} + S_t                        (Eq. 13)  alpha = forgetting gate
  y_t = M*(q_t)  (forward pass, no weight update)            (Eq. 15)
Chunked training (Eq. 16): every gradient inside a chunk is taken at the weights that existed at the
start of that chunk, so the gradients of one chunk are computed in parallel with vmap.

Verified on CPU in tests/test_memory.py (causality, state carry, outer-loop gradients, recall).
Memory weights, momentum, gates and the inner loss always run in fp32.
"""
import math

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.func import functional_call, grad, vmap


def chunk_update_loop(W, S, G, theta, eta, alpha):
    """Reference: Eqs. 13-14 applied token by token. theta/eta/alpha: (N, b). G[n]: (N, b, ...).
    Correct but stores a full weight copy per token in the autograd graph -> OOM when training."""
    W, S = dict(W), dict(S)
    for t in range(theta.shape[1]):
        for n in W:
            shp = (-1,) + (1,) * (W[n].dim() - 1)
            S[n] = eta[:, t].view(shp) * S[n] - theta[:, t].view(shp) * G[n][:, t]
            W[n] = (1 - alpha[:, t]).view(shp) * W[n] + S[n]
    return W, S


def chunk_update(W, S, G, theta, eta, alpha):
    """Exact closed form of chunk_update_loop (same result, O(b^2) scalars instead of b weight copies).
    With E[i,t] = prod_{j=i+1..t} eta_j and A[t] = prod_{j=t+1..b} (1 - alpha_j):
      S_b = E[0,b] S_0 - sum_i E[i,b] theta_i G_i
      W_b = A[0] W_0 + (sum_t A[t] E[0,t]) S_0 - sum_i theta_i (sum_{t>=i} A[t] E[i,t]) G_i
    Here index 0 means "before the chunk" and tokens are 1..b.
    """
    N, b = theta.shape
    le = torch.log(eta.clamp_min(1e-30))                     # (N, b)
    la = torch.log((1 - alpha).clamp_min(1e-30))
    ce = torch.cumsum(le, 1)                                  # ce[t] = sum_{j<=t} log eta_j
    ca = torch.cumsum(la, 1)
    tot_a = ca[:, -1:]
    A = torch.exp(tot_a - ca)                                 # A[t] = prod_{j>t} (1-alpha_j), (N, b)
    A0 = torch.exp(tot_a).squeeze(1)                          # prod over whole chunk
    E0 = torch.exp(ce)                                        # E[0,t] = prod_{j<=t} eta_j
    idx = torch.arange(b, device=theta.device)
    upper = (idx[None, :] >= idx[:, None])                    # t >= i
    Eit = torch.exp((ce[:, None, :] - ce[:, :, None]).masked_fill(~upper, -float("inf")))  # (N, i, t)
    cW_S0 = (A * E0).sum(1)                                   # coef of S_0 in W_b
    cW_G = theta * (Eit * A[:, None, :]).sum(2)               # (N, b) coef of G_i in W_b
    cS_G = theta * Eit[:, :, -1]                              # E[i,b] theta_i
    eS0 = E0[:, -1]
    Wn, Sn = {}, {}
    for n in W:
        shp = (-1,) + (1,) * (W[n].dim() - 1)
        g = G[n]
        Wn[n] = (A0.view(shp) * W[n] + cW_S0.view(shp) * S[n]
                 - torch.einsum("nb,nb...->n...", cW_G, g))
        Sn[n] = eS0.view(shp) * S[n] - torch.einsum("nb,nb...->n...", cS_G, g)
    return Wn, Sn


class MemoryMLP(nn.Module):
    """Deep memory M(x) = x + W2 . silu(W1 . x). Depth L_M = 2 (paper: >=2 beats linear memory)."""

    def __init__(self, dim: int, expansion: int = 2):
        super().__init__()
        self.w1 = nn.Parameter(torch.randn(dim, dim * expansion) / math.sqrt(dim))
        self.w2 = nn.Parameter(torch.zeros(dim * expansion, dim))  # zero init: starts as identity map

    def forward(self, x):
        return x + F.silu(x @ self.w1) @ self.w2


class NeuralMemory(nn.Module):
    """Titans long-term memory layer.

    forward(x, state=None, update=True) -> (y, new_state)
      x:     (B, T, dim)
      y:     (B, T, dim)  retrieval for each token, read from memory produced by *earlier* chunks only
      state: {"W": {name: (B*heads, ...)}, "S": {...}}  memory weights + momentum, fp32
    """

    def __init__(self, dim, heads=1, dim_head=None, chunk_size=16, max_lr=0.1, expansion=2,
                 conv_kernel=4, huber_delta=None):
        super().__init__()
        self.h = heads
        self.dh = dim_head or dim // heads
        self.chunk = chunk_size
        self.max_lr = max_lr
        inner = self.h * self.dh
        self.to_qkv = nn.Linear(dim, 3 * inner, bias=False)
        # causal depthwise conv after q/k/v projections (paper §4.4; ablation "w/o convolution")
        self.conv = nn.Conv1d(3 * inner, 3 * inner, conv_kernel, groups=3 * inner, padding=conv_kernel - 1)
        self.to_gates = nn.Linear(dim, 3 * heads)  # theta (inner lr), eta (momentum), alpha (forget)
        self.mem = MemoryMLP(self.dh, expansion)  # meta-learned initial memory M_0 (outer-loop params)
        self.norm = nn.RMSNorm(inner)
        self.out_gate = nn.Linear(dim, inner)
        self.out = nn.Linear(inner, dim, bias=False)
        self.huber_delta = huber_delta  # None = paper's L2 loss; float = MIRAS "Yaad"-style Huber loss

        mem = self.mem
        huber = huber_delta

        def assoc_loss(params, k, v):  # single token: k, v (dh,)
            pred = functional_call(mem, params, (k.unsqueeze(0),)).squeeze(0)
            if huber is None:
                return (pred - v).pow(2).sum()
            return F.huber_loss(pred, v, reduction="sum", delta=huber)

        g = grad(assoc_loss)
        # inner vmap: tokens (params shared), outer vmap: batch*heads (each has its own memory)
        self._grads = vmap(vmap(g, in_dims=(None, 0, 0)), in_dims=(0, 0, 0))
        self._read = vmap(lambda p, x: functional_call(mem, p, (x,)))

    def init_state(self, batch: int, device=None):
        W = {n: p.float().unsqueeze(0).expand(batch * self.h, *p.shape).clone()
             for n, p in self.mem.named_parameters()}
        if device is not None:
            W = {n: w.to(device) for n, w in W.items()}
        return {"W": W, "S": {n: torch.zeros_like(w) for n, w in W.items()}}

    @staticmethod
    def detach_state(state):
        return {k: {n: t.detach() for n, t in d.items()} for k, d in state.items()}

    def _split(self, t, B, T):
        return t.reshape(B, T, self.h, self.dh).transpose(1, 2).reshape(B * self.h, T, self.dh)

    def forward(self, x, state=None, update=True):
        with torch.enable_grad():  # torch.func.grad needs this even when the caller is in no_grad
            return self._forward(x, state, update)

    def _forward(self, x, state, update):
        B, T, _ = x.shape
        qkv = self.conv(self.to_qkv(x).transpose(1, 2))[..., :T].transpose(1, 2)  # causal: trim right pad
        q, k, v = F.silu(qkv).float().chunk(3, dim=-1)
        q, k, v = (self._split(t, B, T) for t in (q, k, v))
        q, k = F.normalize(q, dim=-1), F.normalize(k, dim=-1)  # l2-normalised q, k (paper §4.4)

        gates = torch.sigmoid(self.to_gates(x).float())  # (B, T, 3*h)
        gates = gates.view(B, T, 3, self.h).permute(2, 0, 3, 1).reshape(3, B * self.h, T)
        theta, eta, alpha = gates[0] * self.max_lr, gates[1], gates[2]

        if state is None:
            state = self.init_state(B, x.device)
        W, S = dict(state["W"]), dict(state["S"])
        outs = []
        for s in range(0, T, self.chunk):
            e = min(s + self.chunk, T)
            outs.append(self._read(W, q[:, s:e]))  # read with M_{c-1}: strictly causal
            if not update:
                continue
            G = self._grads(W, k[:, s:e], v[:, s:e])  # all grads at chunk-start weights (Eq. 16)
            W, S = chunk_update(W, S, G, theta[:, s:e], eta[:, s:e], alpha[:, s:e])
        y = torch.cat(outs, 1)  # (B*h, T, dh)
        y = y.view(B, self.h, T, self.dh).transpose(1, 2).reshape(B, T, self.h * self.dh)
        y = self.norm(y.to(x.dtype)) * torch.sigmoid(self.out_gate(x))
        new_state = {"W": W, "S": S} if update else state
        return self.out(y), new_state

    @torch.no_grad()
    def surprise(self, x, state):
        """Per-token surprise norm ||grad l|| under current memory. Useful as an importance score."""
        B, T, _ = x.shape
        qkv = self.conv(self.to_qkv(x).transpose(1, 2))[..., :T].transpose(1, 2)
        _, k, v = F.silu(qkv).float().chunk(3, dim=-1)
        k, v = self._split(k, B, T), self._split(v, B, T)
        k = F.normalize(k, dim=-1)
        with torch.enable_grad():
            G = self._grads(state["W"], k, v)
        sq = sum(g.flatten(2).pow(2).sum(-1) for g in G.values())  # (B*h, T)
        return sq.sqrt().view(B, self.h, T).mean(1)
