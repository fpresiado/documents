"""Titans MAG and MAC language models (from scratch). No positional encoding beyond the causal conv
inside NeuralMemory; add RoPE to Attention for real runs.

MAG (paper §4.2, Eqs. 26-28): o = SWA*(x~) (gate) M(x~), x~ = [P || x]
MAC (paper §4.1, Eqs. 21-25): per segment S_t:
    h_t = M*_{t-1}(q_t)            retrieve history with memory from previous segments
    y_t = Attn([P || h_t || S_t])  attention over persistent tokens + history + segment
    M_t = M_{t-1}(y_t)             write y_t into memory
    o_t = y_t (gate) M*_t(y_t)
CAUSALITY NOTE (MAC): the paper computes q_t from the whole segment, so h_t[i] carries information
about token i. In an autoregressive LM, token j must not see h_t[i] for i > j. The paper does not
spell out the mask; here segment token j sees persistent tokens, h_t[0..j] and S_t[0..j]. Tested in
tests/test_model.py::test_mac_causal.
"""
import torch
import torch.nn as nn

from .attention import MLP, Attention, sliding_window_mask
from .memory import NeuralMemory


class MAGBlock(nn.Module):
    def __init__(self, dim, heads, window, n_persist, chunk=16, use_memory=True):
        super().__init__()
        self.window, self.np, self.use_memory = window, n_persist, use_memory
        self.n1, self.n2, self.gy, self.gm = (nn.RMSNorm(dim) for _ in range(4))
        self.attn, self.mlp = Attention(dim, heads), MLP(dim)
        self.mem = NeuralMemory(dim, 1, chunk_size=chunk) if use_memory else None

    def forward(self, x, state):
        h = self.n1(x)
        y = self.attn(h, sliding_window_mask(h.size(1), self.window, self.np, h.device))
        if self.use_memory:
            m, state = self.mem(h, state)
            x = x + self.gy(y) * torch.sigmoid(self.gm(m))  # Eq. 28, normalised branches, nonlinear gate
        else:
            x = x + y
        return x + self.mlp(self.n2(x)), state


class TitanMAG(nn.Module):
    """Stateful across calls: pass the returned states back in to continue a stream."""

    def __init__(self, vocab, dim=512, depth=8, heads=8, window=256, n_persist=16, chunk=16,
                 use_memory=True):
        super().__init__()
        self.np = n_persist
        self.emb = nn.Embedding(vocab, dim)
        self.persist = nn.Parameter(torch.randn(n_persist, dim) * 0.02)  # Eq. 19
        self.blocks = nn.ModuleList(
            MAGBlock(dim, heads, window, n_persist, chunk, use_memory) for _ in range(depth))
        self.norm, self.head = nn.RMSNorm(dim), nn.Linear(dim, vocab, bias=False)

    def forward(self, ids, states=None):
        x = self.emb(ids)
        x = torch.cat([self.persist.expand(x.size(0), -1, -1), x], 1)
        states = states or [None] * len(self.blocks)
        new = []
        for blk, st in zip(self.blocks, states):
            x, st = blk(x, st)
            new.append(st)
        return self.head(self.norm(x[:, self.np:])), new


def mac_mask(n_persist, L, device):
    """Mask over [P (n_persist) | h (L) | S (L)]; True = may attend."""
    N = n_persist + 2 * L
    m = torch.zeros(N, N, dtype=torch.bool, device=device)
    m[:, :n_persist] = True  # persistent tokens visible to all
    idx = torch.arange(L, device=device)
    causal = idx[None, :] <= idx[:, None]  # (L, L)
    hs, ss = slice(n_persist, n_persist + L), slice(n_persist + L, N)
    m[hs, hs] = causal       # h_i sees h_0..h_i
    m[ss, hs] = causal       # s_j sees h_0..h_j   (no future leak)
    m[ss, ss] = causal       # s_j sees s_0..s_j
    return m


class TitanMAC(nn.Module):
    def __init__(self, vocab, dim=512, depth=8, heads=8, seg=128, n_persist=16, chunk=16):
        super().__init__()
        self.seg, self.np = seg, n_persist
        self.emb = nn.Embedding(vocab, dim)
        self.persist = nn.Parameter(torch.randn(n_persist, dim) * 0.02)
        self.attn = nn.ModuleList(Attention(dim, heads) for _ in range(depth))
        self.mlp = nn.ModuleList(MLP(dim) for _ in range(depth))
        self.mem = nn.ModuleList(NeuralMemory(dim, 1, chunk_size=chunk) for _ in range(depth))
        self.n1 = nn.ModuleList(nn.RMSNorm(dim) for _ in range(depth))
        self.n2 = nn.ModuleList(nn.RMSNorm(dim) for _ in range(depth))
        self.norm, self.head = nn.RMSNorm(dim), nn.Linear(dim, vocab, bias=False)

    def forward(self, ids, states=None):
        B, T = ids.shape
        states = list(states) if states else [None] * len(self.attn)
        outs = []
        for s in range(0, T, self.seg):
            x = self.emb(ids[:, s:s + self.seg])
            L = x.size(1)
            mask = mac_mask(self.np, L, x.device)
            for i in range(len(self.attn)):
                h = self.n1[i](x)
                hist, _ = self.mem[i](h, states[i], update=False)             # Eq. 21
                z = torch.cat([self.persist.expand(B, -1, -1), hist, h], 1)    # Eq. 22
                y = self.attn[i](z, mask)[:, self.np + L:]                      # Eq. 23
                _, states[i] = self.mem[i](y, states[i], update=True)          # Eq. 24
                r, _ = self.mem[i](y, states[i], update=False)
                x = x + y * torch.sigmoid(r)                                    # Eq. 25
                x = x + self.mlp[i](self.n2[i](x))
            outs.append(x)
        return self.head(self.norm(torch.cat(outs, 1))), states
