"""Short-term memory: causal attention (optionally sliding-window) + SwiGLU MLP."""
import torch
import torch.nn as nn
import torch.nn.functional as F


def sliding_window_mask(T, window, n_prefix, device):
    """Bool mask (True = may attend). Causal, local window, persistent prefix always visible."""
    i = torch.arange(T, device=device)[:, None]
    j = torch.arange(T, device=device)[None, :]
    return (j <= i) & (((i - j) < window) | (j < n_prefix))


class Attention(nn.Module):
    def __init__(self, dim, heads=8):
        super().__init__()
        assert dim % heads == 0
        self.h = heads
        self.qkv = nn.Linear(dim, 3 * dim, bias=False)
        self.o = nn.Linear(dim, dim, bias=False)

    def forward(self, x, mask):
        B, T, D = x.shape
        q, k, v = self.qkv(x).view(B, T, 3, self.h, D // self.h).permute(2, 0, 3, 1, 4)
        y = F.scaled_dot_product_attention(q, k, v, attn_mask=mask)  # AOTriton path on ROCm
        return self.o(y.transpose(1, 2).reshape(B, T, D))


class MLP(nn.Module):
    def __init__(self, dim, mult=4):
        super().__init__()
        self.a = nn.Linear(dim, 2 * mult * dim, bias=False)
        self.b = nn.Linear(mult * dim, dim, bias=False)

    def forward(self, x):
        u, g = self.a(x).chunk(2, -1)
        return self.b(u * F.silu(g))
