"""Persist Titans memory state across sessions (safetensors, atomic write, checkpoint-bound)."""
import hashlib
import json
import os

import torch
from safetensors import safe_open
from safetensors.torch import load_file, save_file


def ckpt_hash(model) -> str:
    """Hash of the full model weights. A memory state is only valid for the exact weights that made it."""
    h = hashlib.sha256()
    for n, p in sorted(model.state_dict().items()):
        h.update(n.encode())
        h.update(p.detach().float().contiguous().cpu().numpy().tobytes())
    return h.hexdigest()[:16]


def save_states(path, states, model, meta=None):
    flat = {}
    for li, st in enumerate(states):
        if st is None:
            continue
        for kind in ("W", "S"):
            for n, t in st[kind].items():
                flat[f"{li}.{kind}.{n}"] = t.detach().float().contiguous().cpu()
    info = {**(meta or {}), "ckpt": ckpt_hash(model), "n_layers": len(states)}
    tmp = path + ".tmp"
    save_file(flat, tmp, metadata={"meta": json.dumps(info)})
    os.replace(tmp, path)  # atomic


def load_states(path, model, device="cpu"):
    with safe_open(path, "pt") as f:
        meta = json.loads(f.metadata()["meta"])
    if meta["ckpt"] != ckpt_hash(model):
        raise RuntimeError("memory state was produced by different model weights; refusing to load")
    flat = load_file(path, device=str(device))
    states = [None] * meta["n_layers"]
    for key, t in flat.items():
        li, kind, name = key.split(".", 2)
        li = int(li)
        if states[li] is None:
            states[li] = {"W": {}, "S": {}}
        states[li][kind][name] = t
    return states, meta
