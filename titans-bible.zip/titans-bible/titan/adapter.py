"""Titans memory adapter for a FROZEN Hugging Face decoder (Llama/Qwen/Gemma-style `model.model.layers`).

Pattern follows public retrofit work (javilima01/Titans, TPTT arXiv 2506.17671). Only adapter params train.
The gate starts near zero so the frozen model's behaviour is unchanged at init (roadmap gate P7).
Tested in tests/test_adapter.py against a tiny stand-in decoder (no HF download needed).
"""
import torch
import torch.nn as nn

from .memory import NeuralMemory


class MemoryAdapter(nn.Module):
    def __init__(self, hidden, mem_dim=512, chunk=32, gate_init=-4.0):
        super().__init__()
        self.down = nn.Linear(hidden, mem_dim)
        self.up = nn.Linear(mem_dim, hidden)
        self.mem = NeuralMemory(mem_dim, chunk_size=chunk)
        self.gate = nn.Parameter(torch.full((hidden,), gate_init))  # sigmoid(-4) ~= 0.018
        self.state = None  # carried across forward calls = memory across turns

    def reset(self):
        self.state = None

    def forward(self, h):
        y, self.state = self.mem(self.down(h.float()), self.state)
        return h + (torch.sigmoid(self.gate) * self.up(y)).to(h.dtype)


def attach(model, layers=(12,), **kw):
    """Freeze `model`, add adapters after the given decoder layers. Returns (ModuleDict, hook handles)."""
    for p in model.parameters():
        p.requires_grad_(False)
    hidden = model.config.hidden_size
    dev = next(model.parameters()).device
    ads, handles = nn.ModuleDict(), []
    for i in layers:
        ad = ads[str(i)] = MemoryAdapter(hidden, **kw).to(dev)

        def hook(mod, inp, out, ad=ad):
            if isinstance(out, tuple):
                return (ad(out[0]),) + tuple(out[1:])
            return ad(out)

        handles.append(model.model.layers[i].register_forward_hook(hook))
    return ads, handles
