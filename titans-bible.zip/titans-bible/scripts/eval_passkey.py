"""Passkey retrieval: hide a 5-digit key in filler text, stream it through the model, ask for it back.

  python scripts/eval_passkey.py --ckpt runs/tiny_mem/ckpt.pt --lengths 2000 8000 32000
A byte-level model only passes this after it has learned to copy; use it to compare memory vs
no-memory checkpoints trained identically (roadmap gate P4), not as an absolute score.
"""
import argparse
import json
import os
import random
import sys

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from titan.model import TitanMAC, TitanMAG  # noqa: E402

FILL = "The grass is green. The sky is blue. The sun is yellow. Here we go. There and back again. "


def make_prompt(n_chars, key):
    f = (FILL * (n_chars // len(FILL) + 1))[:n_chars]
    p = random.randint(0, len(f))
    return f[:p] + f" The pass key is {key}. Remember it. {key} is the pass key. " + f[p:] + " The pass key is "


@torch.no_grad()
def passkey(model, dev, lengths, trials, seg):
    res = {}
    for n in lengths:
        ok = 0
        for _ in range(trials):
            key = str(random.randint(10000, 99999))
            ids = torch.tensor([list(make_prompt(n, key).encode())], device=dev)
            st, logits = None, None
            for s in range(0, ids.size(1), seg):  # stream; memory carries the long context
                logits, st = model(ids[:, s:s + seg], st)
            out = ""
            for _ in range(5):
                nxt = logits[:, -1].argmax(-1, keepdim=True)
                out += chr(nxt.item())
                logits, st = model(nxt, st)
            ok += out == key
        res[n] = ok / trials
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--lengths", type=int, nargs="+", default=[2000, 8000, 32000])
    ap.add_argument("--trials", type=int, default=20)
    a = ap.parse_args()
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    ck = torch.load(a.ckpt, map_location=dev)
    c = ck["cfg"]
    if c["arch"] == "mag":
        model = TitanMAG(256, c["dim"], c["depth"], c["heads"], c["window"], c["n_persist"], c["chunk"],
                         use_memory=not c["no_memory"])
    else:
        model = TitanMAC(256, c["dim"], c["depth"], c["heads"], c["window"], c["n_persist"], c["chunk"])
    model.load_state_dict(ck["model"])
    model.to(dev).eval()
    print(json.dumps(passkey(model, dev, a.lengths, a.trials, c["seq"])))


if __name__ == "__main__":
    main()
