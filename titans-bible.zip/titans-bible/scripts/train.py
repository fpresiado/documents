"""Byte-level training for TitanMAG / TitanMAC with truncated BPTT over memory state.

  python scripts/train.py --data data/enwik8 --preset tiny --steps 300 --name tiny_mem
  python scripts/train.py --data data/enwik8 --preset tiny --steps 300 --name tiny_nomem --no-memory
Logs runs/<name>/metrics.jsonl and ckpt.pt. Device: cuda (== ROCm/HIP) if available, else cpu.
"""
import os

os.environ.setdefault("TORCH_ROCM_AOTRITON_ENABLE_EXPERIMENTAL", "1")  # must precede torch import

import argparse
import json
import math
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from titan.memory import NeuralMemory  # noqa: E402
from titan.model import TitanMAC, TitanMAG  # noqa: E402

PRESETS = {
    "tiny": dict(dim=128, depth=4, heads=4, window=64, n_persist=4, chunk=16, seq=256, bptt=2, batch=8),
    "small": dict(dim=384, depth=6, heads=6, window=128, n_persist=8, chunk=16, seq=512, bptt=4, batch=8),
    "base": dict(dim=768, depth=12, heads=12, window=256, n_persist=16, chunk=16, seq=1024, bptt=4, batch=4),
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True, help="raw byte file (e.g. enwik8)")
    ap.add_argument("--preset", default="tiny", choices=PRESETS)
    ap.add_argument("--arch", default="mag", choices=["mag", "mac"])
    ap.add_argument("--steps", type=int, default=20000)
    ap.add_argument("--lr", type=float, default=3e-4)
    ap.add_argument("--name", default="run")
    ap.add_argument("--no-memory", action="store_true")
    ap.add_argument("--log-every", type=int, default=50)
    ap.add_argument("--bf16", action="store_true", help="bf16 autocast (memory math stays fp32)")
    a = ap.parse_args()
    c = PRESETS[a.preset]
    dev = "cuda" if torch.cuda.is_available() else "cpu"

    data = np.memmap(a.data, dtype=np.uint8, mode="r")
    split = int(len(data) * 0.9)
    train, val = data[:split], data[split:]

    if a.arch == "mag":
        model = TitanMAG(256, c["dim"], c["depth"], c["heads"], c["window"], c["n_persist"], c["chunk"],
                         use_memory=not a.no_memory)
    else:
        model = TitanMAC(256, c["dim"], c["depth"], c["heads"], c["window"], c["n_persist"], c["chunk"])
    model.to(dev)
    print(f"params: {sum(p.numel() for p in model.parameters()) / 1e6:.2f}M  device: {dev}")

    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, weight_decay=0.1, betas=(0.9, 0.95))
    warm = min(500, a.steps // 10 + 1)
    sched = torch.optim.lr_scheduler.LambdaLR(
        opt, lambda s: min(1, (s + 1) / warm) * 0.5 * (1 + math.cos(math.pi * min(s, a.steps) / a.steps)))

    L = c["seq"] * c["bptt"] + 1

    def batch(src):
        ix = np.random.randint(0, len(src) - L, c["batch"])
        return torch.from_numpy(np.stack([src[i:i + L] for i in ix]).astype(np.int64)).to(dev)

    def run(x, train_mode):
        states, tot = None, 0.0
        for sg in range(c["bptt"]):  # truncated BPTT: memory content carries, graph is cut
            s = sg * c["seq"]
            inp, tgt = x[:, s:s + c["seq"]], x[:, s + 1:s + c["seq"] + 1]
            with torch.autocast(dev, dtype=torch.bfloat16, enabled=a.bf16):
                logits, states = model(inp, states)
            loss = F.cross_entropy(logits.float().reshape(-1, 256), tgt.reshape(-1))
            if train_mode:
                (loss / c["bptt"]).backward()
            states = [NeuralMemory.detach_state(st) if st else None for st in states]
            tot += loss.item() / c["bptt"]
        return tot

    os.makedirs(f"runs/{a.name}", exist_ok=True)
    json.dump({**c, **vars(a)}, open(f"runs/{a.name}/config.json", "w"), indent=2)
    log = open(f"runs/{a.name}/metrics.jsonl", "a")
    t0 = time.time()
    for step in range(a.steps):
        model.train()
        tr = run(batch(train), True)
        if not math.isfinite(tr):
            raise SystemExit(f"non-finite loss at step {step}: lower max_lr / check bf16 path")
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        opt.zero_grad(set_to_none=True)
        sched.step()
        if step % a.log_every == 0 or step == a.steps - 1:
            model.eval()
            with torch.no_grad():
                va = run(batch(val), False)
            rec = {"step": step, "train_bpb": tr / math.log(2), "val_bpb": va / math.log(2),
                   "tok_s": (step + 1) * c["batch"] * c["seq"] * c["bptt"] / (time.time() - t0)}
            print(json.dumps(rec))
            log.write(json.dumps(rec) + "\n")
            log.flush()
        if step % 1000 == 0 or step == a.steps - 1:
            torch.save({"model": model.state_dict(), "cfg": {**c, **vars(a)}, "step": step},
                       f"runs/{a.name}/ckpt.pt")


if __name__ == "__main__":
    main()
