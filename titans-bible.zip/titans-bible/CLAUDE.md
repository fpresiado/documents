# CLAUDE.md — titan-local (Titans-style memory AI, zero cloud)

## Mission
Local AI with a Titans-style neural long-term memory: an MLP whose weights are trained *while the model
runs*. Track A: small from-scratch LM (MAG, then MAC) to validate the mechanism. Track B: memory adapter
on a frozen open-weight LLM for the real agent, with memory persisted to disk per user.

## Read order
1. `docs/00_INDEX.md` (map + what each claim's verification tag means)
2. `docs/VERIFICATION.md` (errata: bugs found in the earlier single-file report — do NOT reuse that code)
3. `docs/01`–`03` before touching `titan/`; `docs/08` before touching the environment
4. `docs/11_roadmap.md` is the task list. Work phase by phase; a phase is done only when its gate passes.

## Ground rules (never violate)
1. No network calls at runtime. Assets are fetched once by explicit scripts only.
2. Memory weights, momentum, gates and the inner loss stay fp32, even with a bf16 backbone.
3. Every memory read is causal: chunk c reads memory produced by chunks < c. `pytest tests/` checks it.
4. Inner learning rate is capped (`max_lr`, default 0.1). `max_lr≈1` diverges (tests/test_memory.py).
5. Use `chunk_update` (closed form). `chunk_update_loop` is a reference only (one weight copy per token in the graph).
6. Pin every dependency. Upgrading = code change: update `requirements.txt`, rerun all tests.
7. Strix Halo: `TORCH_ROCM_AOTRITON_ENABLE_EXPERIMENTAL=1` before `import torch`;
   do NOT set `HSA_OVERRIDE_GFX_VERSION` with native gfx1151 wheels. See docs/08.
8. Never wrap NeuralMemory in activation checkpointing / saved-tensor hooks (torch.func conflict).
9. Memory state files are bound to a checkpoint hash; `load_states` refuses a mismatch. Keep it that way.
10. "Done" = `python -m pytest -q` passes AND the phase gate in docs/11 passes. Log evals to runs/<name>/.
11. Don't call anything "official Titans": Google released no code or weights.

## Layout
```
titan/memory.py      NeuralMemory, MemoryMLP, chunk_update (+ loop reference)
titan/attention.py   causal / sliding-window attention, SwiGLU MLP
titan/model.py       TitanMAG, TitanMAC (causal MAC mask), no-memory baseline flag
titan/state_io.py    save/load memory state (safetensors, atomic, hash-bound)
titan/adapter.py     MemoryAdapter + attach() for frozen HF decoders
scripts/train.py     byte-level training, truncated BPTT, --arch mag|mac, --no-memory, --bf16
scripts/eval_passkey.py
tests/               16 tests, all passing on CPU (torch 2.14.0+cpu) at time of writing
docs/                the bible, one topic per file
```

## Commands
```bash
python -m pytest -q
python scripts/train.py --data data/enwik8 --preset small --steps 20000 --name mag_small --bf16
python scripts/train.py --data data/enwik8 --preset small --steps 20000 --name base_small --no-memory --bf16
python scripts/eval_passkey.py --ckpt runs/mag_small/ckpt.pt --lengths 2000 8000 32000
```
