#!/usr/bin/env bash
# source env/strix_halo.sh  (see docs/08)
export TORCH_ROCM_AOTRITON_ENABLE_EXPERIMENTAL=1
unset HSA_OVERRIDE_GFX_VERSION
unset PYTORCH_HIP_ALLOC_CONF
