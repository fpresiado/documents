import torch

from titan.memory import NeuralMemory


def test_shapes_and_causality():
    torch.manual_seed(0)
    m = NeuralMemory(64, heads=2, chunk_size=8)
    x = torch.randn(2, 32, 64)
    y, _ = m(x)
    assert y.shape == x.shape
    x2 = x.clone()
    x2[:, 24:] += 5.0  # change only the future
    y2, _ = m(x2)
    assert torch.allclose(y[:, :24], y2[:, :24], atol=1e-5)


def test_state_carries_information():
    torch.manual_seed(0)
    m = NeuralMemory(32, chunk_size=4, max_lr=0.5)
    x = torch.randn(1, 64, 32)
    _, st = m(x)
    a, _ = m(x, st, update=False)
    b, _ = m(x, None, update=False)
    assert not torch.allclose(a, b)


def test_update_false_leaves_state_untouched():
    torch.manual_seed(0)
    m = NeuralMemory(32, chunk_size=4)
    _, st = m(torch.randn(1, 16, 32))
    before = {n: t.clone() for n, t in st["W"].items()}
    _, st2 = m(torch.randn(1, 16, 32), st, update=False)
    for n in before:
        assert torch.equal(before[n], st2["W"][n])


def test_outer_loop_gradients_flow():
    m = NeuralMemory(32, chunk_size=4)
    y, _ = m(torch.randn(1, 16, 32))
    y.sum().backward()
    for p in (m.to_gates.weight, m.to_qkv.weight, m.mem.w1, m.conv.weight):
        assert p.grad is not None and p.grad.abs().sum() > 0


def test_works_under_no_grad():
    m = NeuralMemory(32, chunk_size=4)
    with torch.no_grad():
        y, st = m(torch.randn(1, 16, 32))
    assert torch.isfinite(y).all()


def test_inner_loop_reduces_assoc_loss():
    """Writing the same k->v data repeatedly must lower the associative loss (memory actually learns)."""
    torch.manual_seed(0)
    m = NeuralMemory(32, chunk_size=8, max_lr=0.1)
    with torch.no_grad():
        m.to_gates.bias.copy_(torch.tensor([3.0, -3.0, -6.0]))  # high lr, low momentum, ~no forgetting
    x = torch.randn(1, 8, 32)

    def assoc_loss(state):
        import torch.nn.functional as F
        from torch.func import functional_call
        B, T, _ = x.shape
        qkv = m.conv(m.to_qkv(x).transpose(1, 2))[..., :T].transpose(1, 2)
        _, k, v = F.silu(qkv).float().chunk(3, dim=-1)
        k = F.normalize(k, dim=-1)
        W = {n: w[0] for n, w in state["W"].items()}
        return (functional_call(m.mem, W, (k[0],)) - v[0]).pow(2).sum().item()

    st = m.init_state(1)
    l0 = assoc_loss(st)
    with torch.no_grad():
        for _ in range(5):
            _, st = m(x, st)
    assert assoc_loss(st) < 0.5 * l0


def test_huber_variant_runs():
    m = NeuralMemory(32, chunk_size=4, huber_delta=1.0)
    y, _ = m(torch.randn(1, 12, 32))
    assert torch.isfinite(y).all()


def test_too_high_inner_lr_diverges():
    """Documents a real hazard: with max_lr ~1 and chunk 8 the summed chunk gradients overshoot."""
    torch.manual_seed(0)
    m = NeuralMemory(32, chunk_size=8, max_lr=1.0)
    with torch.no_grad():
        m.to_gates.bias.copy_(torch.tensor([3.0, -3.0, -6.0]))
    x = torch.randn(1, 8, 32)
    st = None
    with torch.no_grad():
        for _ in range(5):
            _, st = m(x, st)
    assert not all(torch.isfinite(w).all() and w.abs().max() < 1e3 for w in st["W"].values())


def test_closed_form_chunk_update_matches_loop():
    from titan.memory import chunk_update, chunk_update_loop
    torch.manual_seed(0)
    N, b = 3, 16
    W = {"w1": torch.randn(N, 8, 16, dtype=torch.float64), "w2": torch.randn(N, 16, 8, dtype=torch.float64)}
    S = {n: torch.randn_like(w) for n, w in W.items()}
    G = {n: torch.randn(N, b, *w.shape[1:], dtype=torch.float64) for n, w in W.items()}
    th, et, al = (torch.rand(N, b, dtype=torch.float64) for _ in range(3))
    W1, S1 = chunk_update_loop(W, S, G, th, et, al)
    W2, S2 = chunk_update(W, S, G, th, et, al)
    for n in W:
        assert torch.allclose(W1[n], W2[n], atol=1e-9)
        assert torch.allclose(S1[n], S2[n], atol=1e-9)
