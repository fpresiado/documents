import pytest
import torch

from titan.model import TitanMAG
from titan.state_io import load_states, save_states


def test_roundtrip_and_hash_guard(tmp_path):
    torch.manual_seed(0)
    m = TitanMAG(64, dim=32, depth=2, heads=4, window=8, n_persist=4, chunk=4)
    ids = torch.randint(0, 64, (1, 24))
    _, st = m(ids)
    p = str(tmp_path / "mem.safetensors")
    save_states(p, st, m, {"user": "test"})

    st2, meta = load_states(p, m)
    assert meta["user"] == "test"
    a, _ = m(ids[:, :8], st)
    b, _ = m(ids[:, :8], st2)
    assert torch.allclose(a, b, atol=1e-5)  # a new process would see the identical memory

    with torch.no_grad():
        m.head.weight.add_(1.0)  # different weights -> must refuse
    with pytest.raises(RuntimeError):
        load_states(p, m)
