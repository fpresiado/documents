import torch

from titan.model import TitanMAC, TitanMAG


def _causal_check(model, T=48, cut=30):
    torch.manual_seed(0)
    ids = torch.randint(0, 64, (1, T))
    a, _ = model(ids)
    ids2 = ids.clone()
    ids2[:, cut:] = (ids2[:, cut:] + 7) % 64
    b, _ = model(ids2)
    return torch.allclose(a[:, :cut], b[:, :cut], atol=1e-4)


def test_mag_causal():
    m = TitanMAG(64, dim=32, depth=2, heads=4, window=8, n_persist=4, chunk=4)
    assert _causal_check(m)


def test_mac_causal():
    m = TitanMAC(64, dim=32, depth=2, heads=4, seg=16, n_persist=4, chunk=4)
    assert _causal_check(m)


def test_streaming_state_is_used():
    torch.manual_seed(0)
    m = TitanMAG(64, dim=32, depth=2, heads=4, window=8, n_persist=4, chunk=4)
    ids = torch.randint(0, 64, (1, 32))
    _, st = m(ids)
    a, _ = m(ids[:, :8], st)
    b, _ = m(ids[:, :8], None)
    assert not torch.allclose(a, b)


def test_mag_trains():
    torch.manual_seed(0)
    m = TitanMAG(32, dim=32, depth=2, heads=4, window=8, n_persist=2, chunk=4)
    opt = torch.optim.AdamW(m.parameters(), lr=3e-3)
    ids = torch.randint(0, 32, (4, 33))
    first = None
    for _ in range(40):
        logits, _ = m(ids[:, :-1])
        loss = torch.nn.functional.cross_entropy(logits.reshape(-1, 32), ids[:, 1:].reshape(-1))
        opt.zero_grad()
        loss.backward()
        opt.step()
        first = first or loss.item()
    assert loss.item() < 0.7 * first


def test_no_memory_baseline_runs():
    m = TitanMAG(64, dim=32, depth=2, heads=4, window=8, n_persist=4, use_memory=False)
    logits, _ = m(torch.randint(0, 64, (1, 16)))
    assert logits.shape == (1, 16, 64)
