import types

import torch
import torch.nn as nn

from titan.adapter import attach


class TinyDecoder(nn.Module):
    """Stand-in with the HF layout: model.model.layers[i] returning a tuple, model.config.hidden_size."""

    def __init__(self, hidden=32, n=4, vocab=50):
        super().__init__()
        self.config = types.SimpleNamespace(hidden_size=hidden)
        self.emb = nn.Embedding(vocab, hidden)
        self.model = nn.Module()
        self.model.layers = nn.ModuleList(nn.Linear(hidden, hidden) for _ in range(n))
        self.head = nn.Linear(hidden, vocab)
        for layer in self.model.layers:
            layer.register_forward_hook(lambda m, i, o: (o,))  # HF layers return tuples

    def forward(self, ids):
        h = self.emb(ids)
        for layer in self.model.layers:
            h = torch.tanh(layer(h)[0])
        return self.head(h)


def test_adapter_near_identity_at_init_and_only_adapter_trains():
    torch.manual_seed(0)
    base = TinyDecoder()
    ids = torch.randint(0, 50, (1, 20))
    ref = base(ids).detach()
    ads, handles = attach(base, layers=(1,), mem_dim=16, chunk=4)
    out = base(ids)
    assert (out - ref).abs().max() < 0.05  # gate ~0.018 at init
    out.sum().backward()
    assert all(p.grad is None for n, p in base.named_parameters() if not n.startswith("_"))
    assert ads["1"].gate.grad is not None
    for h in handles:
        h.remove()
